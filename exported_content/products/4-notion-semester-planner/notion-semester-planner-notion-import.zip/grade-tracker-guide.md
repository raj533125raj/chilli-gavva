# Grade Tracker Guide

The Grade Tracker turns your final grades and credit hours into an instant GPA calculation.

- **Final Grade**: Enter the percentage you earned for the course.
- **Credits**: Pulled automatically from the Courses database.
- **GPA Contribution**: Formula = Final Grade × Credits.
- **Semester GPA**: Roll‑up = Σ(GPA Contribution) ÷ Σ(Credits).

As soon as you update a grade, the GPA updates across the entire semester. This lets you see the impact of each course on your overall performance.