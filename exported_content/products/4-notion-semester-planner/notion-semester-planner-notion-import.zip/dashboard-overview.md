# Dashboard Overview

The Dashboard is the hub of your semester:

- **Quick‑links** to Courses, Assignments, Exams, Resources, and the Weekly Planner.
- **Calendar view** that merges all course events, assignment due dates, and exam dates.
- **This Week** roll‑up highlighting the top priorities for the next seven days.
- **Current GPA** displayed in a single‑line summary box.

Use the Dashboard each morning to get a snapshot of what’s coming up and where your focus should be.