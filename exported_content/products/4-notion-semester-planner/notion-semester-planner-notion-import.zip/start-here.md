# Start Here

Welcome to the Notion Student Semester Planner & Grade Tracker! This template is ready to use right after you duplicate it into your workspace.

1. Click **Duplicate** on the Gumroad download page.
2. Open the duplicated page in Notion.
3. Follow the quick‑start steps in the next pages to add your courses and start tracking assignments, exams, and grades.

That’s it—no complex setup required.