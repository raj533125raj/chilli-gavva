# Dashboard Overview

The Dashboard gives you a bird’s‑eye view of your content pipeline.

- **Weekly Snapshot** – shows the next 7 days of scheduled posts.
- **Today’s Top 3** – roll‑up of the most urgent tasks across all databases.
- **Quick Links** – jump straight to Idea Bank, Content Calendar, Repurposing Checklist, or Resources.

Use the filters at the top of each view to focus on a specific platform or status.