# Start Here

Welcome! This template is designed to be a one‑stop shop for planning, publishing, and repurposing your content.

1. **Duplicate** the template into your workspace.
2. Explore the **Dashboard** page to see quick links to each database.
3. Begin adding ideas to the **Idea Bank**.
4. Move ideas into the **Content Calendar** when you’re ready to schedule.
5. After publishing, use the **Repurposing Checklist** to turn each piece into multiple assets.

If you need help, check the **Resources & SOPs** page for step‑by‑step guides and video tutorials.